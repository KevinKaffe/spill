package com.kevin;

public enum State {

	MENU,
	GAME
}
