package com.kevin;

public enum Effect {
	SpeedUp,
	SpeedDown,
	SpeedMax,
	SpeedMin,
	FireUp,
	FireDown,
	FireMax,
	FireMin,
	BombUp,
	BombDown,
	BombMax,
	BombMin,
	BombPass,
	SoftPass
}
