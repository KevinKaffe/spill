package com.kevin;

public class Tower extends Tile{

	public Tower(String imgSrc, int x, int y) {
		super(imgSrc, x, y);
	}
	
}
