package com.kevin;

public enum Character {
	Trump,
	Hillary
}
