package com.kevin;

public enum PlayerType {
	Player1,
	Player2,
	AI;
}
