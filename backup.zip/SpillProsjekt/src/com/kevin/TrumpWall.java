package com.kevin;

public class TrumpWall extends Tile{

	public TrumpWall(String imgSrc, int x, int y) {
		super(imgSrc, x, y);
		// TODO Auto-generated constructor stub
	}

}
