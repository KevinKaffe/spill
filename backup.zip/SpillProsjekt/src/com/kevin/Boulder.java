package com.kevin;

public class Boulder extends Tile{

	public Boulder(String imgSrc, int x, int y) {
		super(imgSrc, x, y);
	}
	
}
